<?php
/**
 * Odinstalowanie Segregatora maila.
 * Domyślnie dane ZOSTAJĄ; pełne czyszczenie tylko przy zaznaczonej opcji.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$segm_ust = get_option( 'segm_ustawienia', array() );

// Sekret właściciela (klucz API) kasowany ZAWSZE, niezależnie od opcji „usuń dane"
// (zasada D22: poświadczenia ≠ dane użytkowe; martwa wtyczka nie zostawia klucza
// w bazie — znalezisko wrogiej sesji botów 19.08, zmierzone na czystym WP).
delete_option( 'segm_klucz_api' );

if ( empty( $segm_ust['usun_dane'] ) ) {
	return;
}

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}segm_kategorie" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}segm_reguly" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}segm_maile" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}segm_przebiegi" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}segm_ai_uzycie" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

delete_option( 'segm_ustawienia' );
delete_option( 'segm_wersja_schematu' );
