<?php
/**
 * Odinstalowanie ChatBot LIVE.
 * Domyślnie dane ZOSTAJĄ (właściciel może wrócić bez strat).
 * Pełne czyszczenie tylko, gdy w ustawieniach zaznaczono „usuń wszystkie dane".
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * Cron zdejmujemy ZAWSZE i PRZED gałęzią „dane zostają": zaplanowany zaczep bez
 * kodu, który go obsłuży, to nie są dane właściciela, tylko śmieć w
 * `wp_options -> cron`, w który WordPress uderza codziennie. Normalnie zdejmuje
 * go deaktywacja, ale wtyczkę da się usunąć z jej pominięciem (skasowany
 * katalog, „usuń" z listy) — wtedy `uninstall.php` jest jedynym sprzątaczem.
 * Wzorzec bliźniaczej wtyczki (`segregator-maila/uninstall.php`).
 */
wp_clear_scheduled_hook( 'chatl_czyszczenie_historii' );

$chatl_ust = get_option( 'chatl_ustawienia', array() );

// Sekret właściciela (klucz API) kasowany ZAWSZE, niezależnie od opcji „usuń dane":
// poświadczenie to nie są dane użytkowe, a martwa wtyczka nie ma prawa zostawiać
// klucza w bazie.
delete_option( 'chatl_klucz_api' );

if ( empty( $chatl_ust['usun_dane'] ) ) {
	return;
}

global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_qa" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_zgloszenia" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_rozmowy" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_ai_uzycie" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_rate_limit" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_sesje" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}chatl_zdarzenia" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

delete_option( 'chatl_ustawienia' );
delete_option( 'chatl_wersja_schematu' );
delete_option( 'chatl_blad_maila' );
delete_option( 'chatl_blad_ai' );
delete_option( 'chatl_blad_bazy' );
// Liczniki ze schematu ≤ 7 (przed przeniesieniem do chatl_zdarzenia) — instalacja,
// która nigdy nie weszła do panelu po aktualizacji, może je jeszcze mieć.
delete_option( 'chatl_blad_nonce' );
delete_option( 'chatl_pulapka' );
// Nazwa wpisana wprost, a nie przez CHATL_RODO_OPCJA_WSPOLNE: uninstall.php biegnie
// bez ladowania wtyczki, wiec stalej z includes/rodo.php tu nie ma. Slad sesji
// wspoldzielonych (same identyfikatory, bez adresow i tresci) znika razem z danymi.
delete_option( 'chatl_rodo_sesje_wspolne' );

// Znacznik „widziałem ekran powitalny" leży przy KAŻDYM administratorze osobno,
// więc kasujemy go dla wszystkich naraz ($delete_all = true). Bez tego po pełnym
// czyszczeniu zostawałyby sieroty w wp_usermeta.
delete_metadata( 'user', 0, 'chatl_powitanie_zamkniete', '', true );

// Transienty rate-limitu (chatl_rl_*) ze STARSZYCH wersji wtyczki (≤1.1.x —
// od 1.2.0 licznik żyje w tabeli): esc_like() eskejpuje podkreślnik (SQL
// wildcard) + prepare — wzorzec Handbook, żeby nie złapać cudzych wpisów
// o podobnej nazwie.
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_chatl_rl_' ) . '%', $wpdb->esc_like( '_transient_timeout_chatl_rl_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

// Podglądy importu CSV (chatl_import_<id użytkownika>, TTL 15 minut). Zwykle
// wygasają same, ale deinstalacja w trakcie niedokończonego importu zostawiłaby
// w wp_options pytania i odpowiedzi klienta — czyli DANE, po pełnym czyszczeniu.
// Ten sam wzorzec esc_like() + prepare co wyżej.
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_chatl_import_' ) . '%', $wpdb->esc_like( '_transient_timeout_chatl_import_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

// Szkice odpowiedzi OPERATORA (chatl_szkic_op_<id uzytkownika>_<md5 sesji>, TTL 5 minut,
// zapisywane przez chatl_odloz_szkic_operatora() w includes/operator.php przy odrzuconej
// wiadomosci). Wygasaja same, ale deinstalacja tuz po odrzucie zostawilaby w wp_options
// TRESC pisana przez operatora do goscia — czyli dane, po pelnym czyszczeniu.
// Symetria zapis<->sprzatanie: co wtyczka zapisuje, to musi umiec skasowac.
// Ten sam wzorzec esc_like() + prepare co wyzej.
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( '_transient_chatl_szkic_op_' ) . '%', $wpdb->esc_like( '_transient_timeout_chatl_szkic_op_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
